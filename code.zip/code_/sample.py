#调用工具包#
import numpy as np
import os
import pandas as pd
from osgeo import gdal

#读取证据图层#
def read_tif(path):
    gdal.AllRegister()
    filePath = path
    dataset = gdal.Open(filePath)
    Nodata = dataset.GetRasterBand(1).GetNoDataValue()

    adfGeoTransform = dataset.GetGeoTransform()
    nXSize = dataset.RasterXSize  # 列数
    nYSize = dataset.RasterYSize  # 行数
    im_data = dataset.ReadAsArray(0, 0, nXSize, nYSize)
    index = []  # 纬度
    columns = []  # 经度
    for j in range(nYSize):
        lat = adfGeoTransform[3] + j * adfGeoTransform[5]
        index.append(lat)
    for i in range(nXSize):
        lon = adfGeoTransform[0] + i * adfGeoTransform[1]
        columns.append(lon)

    data = pd.DataFrame(im_data, index=index, columns=columns).values
    HTPointX = []
    HTPointY = []
    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            HTPointX.append(columns[j])
            HTPointY.append(index[i])
    data = data.reshape(data.shape[0] * data.shape[1], 1)

    DataIndex = np.where(data != Nodata)
    HTPointX = np.array(HTPointX)
    HTPointX = HTPointX.reshape(data.shape[0], 1)[DataIndex]
    HTPointY = np.array(HTPointY)
    HTPointY = HTPointY.reshape(data.shape[0], 1)[DataIndex]
    HTPointXY = np.array([HTPointX, HTPointY])
    data = data[DataIndex]

    return data, HTPointXY

def read_data():
    Geological_files = os.listdir(r'./data/geological') #读取地质要素图层文件名
    Geological_list = []
    for Geological_file in Geological_files:
        Geological_file_path = os.path.join(r'./data/geological', Geological_file)
        feature_array, _ = read_tif(Geological_file_path)
        feature_array = feature_array.reshape(feature_array.shape[0], 1)
        Geological_list.append(feature_array)
    Geological_array = np.concatenate(Geological_list, axis=1)
    return Geological_array
data_array = read_data() #证据图层
np.save('data_array.npy', data_array) #保存预测数据


#正负样本标签制作#
label1, HTPointXY = read_tif('./label/deposits.tif') #读取正样本栅格图层

label1 = label1.reshape(label1.shape[0], 1)
label0, _ = read_tif('./label/non_deposits.tif') #读取负样本栅格图层
label0 = label0.reshape(label0.shape[0], 1)
all_array = np.concatenate((data_array, HTPointXY.T, label1, label0), axis=1)

#预测数据输出
Geological_name = os.listdir('./data/geological')
DataFrame_header = []
for i in Geological_name:
    DataFrame_header.append(i[:-4])
DataFrame_header.append('XX')
DataFrame_header.append('YY')
DataFrame_header.append('label1')
DataFrame_header.append('label0')
all_array = pd.DataFrame(all_array)
all_array.columns = DataFrame_header
all_array.to_csv(r'rf_data.csv', header=True, index=False) #输出csv格式
