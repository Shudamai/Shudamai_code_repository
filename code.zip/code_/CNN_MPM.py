import pandas as pd
import tensorflow as tf
import os.path
import matplotlib.pyplot as plt
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Dropout, Flatten, Dense, BatchNormalization
import numpy as np
import cv2 as cv
from sklearn.metrics import roc_curve, auc
import math
import matplotlib.pyplot as plt

os.environ['CUDA_DEVICE_ORDER'] = 'PCI_BUS_ID'  # 调用GPU加速
os.environ['CUDA_VISIBLE_DEVICES'] = '0'

# 读取训练集及标签、验证集及标签#
train_data = np.load("train_data.npy")
train_labels = np.load("train_labels.npy")
valid_data = np.load("valid_data.npy")
valid_labels = np.load("valid_labels.npy")

# 设置窗口大小#
window_size = 9  # 窗口大小
all_channel = 4  # 通道数

# 模型结构搭建#
model = Sequential()
model.add(Conv2D(64, (3, 3), padding='same', activation='relu', input_shape=(window_size, window_size, all_channel)))
# 卷积核尺寸、填充方式、激活函数
model.add(BatchNormalization())  # 正则化项
model.add(MaxPooling2D(pool_size=(2, 2)))  # 池化方式及池化核尺寸
model.add(Conv2D(128, (3, 3), padding='same', activation='relu'))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Flatten())
model.add(Dense(512, activation='relu'))  # 全连接层
model.add(Dropout(0.5))  # 失活层
model.add(Dense(1, activation='sigmoid'))
model.summary()

# 参数设置#
model.compile(
    optimizer=tf.keras.optimizers.Adam(lr=0.00001),  # 优化器类型、学习率
    loss='binary_crossentropy',  # 损失函数类型
    metrics=['acc'])

# 模型训练#
history = model.fit(
    train_data,
    train_labels,
    epochs=300,  # 迭代次数
    batch_size=64,  # 批处理大小
    shuffle=True,
    validation_data=(valid_data, valid_labels), verbose=2)
model.save('model.h5')

# 训练过程输出#
plt.plot(history.epoch, history.history.get('acc'), label='Training set')
plt.plot(history.epoch, history.history.get('val_acc'), label='Validation set')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()
plt.show()
plt.plot(history.epoch, history.history.get('loss'), label='Training set')
plt.plot(history.epoch, history.history.get('val_loss'), label='Validation set')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()
plt.show()

# 保存训练过程#
dataframe = pd.DataFrame({'train_loss': history.history.get('loss'), 'test_loss': history.history.get('val_loss'),
                          'train_acc': history.history.get('acc'), 'test_acc': history.history.get('val_acc')})
dataframe.to_csv("loss_acc.csv", index=False, sep=',')


probability_value = []

# 读取并处理预测数据集#
all_array = np.load('data_array.npy')
label = np.load('./data/label.npy')
X = np.load('./data/X.npy')
Y = np.load('./data/Y.npy')
XY_data = []
TrueArray = []
Truelabel = []
for i in range(X.shape[0]):
    for j in range(X.shape[1]):
        if X[i, j] != -1:
            XY_data.append([X[i, j], Y[i, j]])
            TrueArray.append(all_array[i, j, :])
            Truelabel.append(label[i,j])
all_array = np.array(TrueArray)
XY_data = np.array(XY_data)
label = np.array(Truelabel)

index = np.unique(XY_data[:, 0])
columns = np.unique(XY_data[:, 1])
XY2D = np.zeros([index.shape[0], columns.shape[0], 2])
Feature=np.zeros([index.shape[0], columns.shape[0], all_channel])
label2D=np.zeros([index.shape[0], columns.shape[0]])

for i in range(XY_data.shape[0]):
    XY2D[np.where(index == XY_data[i, 0])[0], np.where(columns == XY_data[i, 1])[0]] = XY_data[i, :]
    Feature[np.where(index == XY_data[i, 0])[0], np.where(columns == XY_data[i, 1])[0]]=all_array[i,:]
    label2D[np.where(index == XY_data[i, 0])[0], np.where(columns == XY_data[i, 1])[0]]=label[i]
all_array=Feature
# 模型预测#
for row in range(all_array.shape[0] - (window_size - 1)):
    for col in range(all_array.shape[1] - (window_size - 1)):
        value = all_array[row:row + window_size, col:col + window_size, :]
        value = value.reshape(1, window_size, window_size, all_channel)
        output = model.predict_proba(value)
        print(output[0][0])
        probability_value.append(output[0][0])

XX = XY2D[:, :, 0]
YY = XY2D[:, :, 1]
# 预测结果输出#
XX_result = XX[math.floor(window_size / 2):XX.shape[0] - math.floor(window_size / 2),
            math.floor(window_size / 2):XX.shape[1] - math.floor(window_size / 2)]
YY_result = YY[math.floor(window_size / 2):YY.shape[0] - math.floor(window_size / 2),
            math.floor(window_size / 2):YY.shape[1] - math.floor(window_size / 2)]
XX_result_list = XX_result.flatten()
YY_result_list = YY_result.flatten()
dataframe = pd.DataFrame({'XX': XX_result_list, 'YY': YY_result_list, 'probability': probability_value})
dataframe.to_csv('cnn_output.csv')  # 输出预测结果

# 模型评价#
label1 = label2D #正样本标签
label1 = label1[math.floor(window_size / 2):label1.shape[0] - math.floor(window_size / 2),
         math.floor(window_size / 2):label1.shape[1] - math.floor(window_size / 2)]
label1 = label1.flatten()
fpr, tpr, threshold = roc_curve(label1, probability_value)
roc_auc = auc(fpr, tpr)

# 绘制ROC曲线#
plt.figure()
plt.plot([0, 1], [0, 1], 'k--')
plt.plot(fpr, tpr, label='AUC=({:.3f})'.format(roc_auc))
plt.legend(loc='best', prop={"family": "Times New Roman", "size": 12})
plt.show()
