#调用工具包#
from sklearn.metrics import roc_curve, auc
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from collections import OrderedDict
from scipy.interpolate import make_interp_spline
import numpy as np
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import cross_val_score

#读取预测数据#
rf_data = pd.read_csv('rf_data.csv')
data_pos = rf_data[rf_data['label1'] == 1] #正样本标签
data_neg = rf_data[rf_data['label0'] == 0] #负样本标签
data_train = pd.concat([data_pos, data_neg])
property = data_train.iloc[:, :42]
label = data_train['label1']

#制作训练集、验证集、测试集#
x_train, x_valid, y_train, y_valid = train_test_split(property, label, train_size=0.8, random_state=17) #按比例分割数据集
train_data = x_train
train_label = y_train
valid_data = property
valid_label = label
test_data = rf_data.iloc[:, :42]

#基于网格搜索法的模型调参#
#优化n_estimators参数
cross = []
for i in range(0, 200, 10): #设置参数搜索范围
    rf = RandomForestClassifier(n_estimators=i+1, n_jobs=-1, random_state=0)
    cross_score = cross_val_score(rf, train_data, train_label, cv=5).mean()
    cross.append(cross_score)
plt.plot(range(1, 201, 10), cross)
plt.xlabel('n_estimators', fontdict={'family': 'Times New Roman', 'size': 12})
plt.ylabel('准确率', fontdict={'family': 'SimSun', 'size': 12})
plt.show()
print('n_estimators:', (cross.index(max(cross))*10)+1) #输出最优参数

#优化max_features参数
param_grid = {'max_features': np.arange(1, 20, 1)} #设置参数搜索范围
rf = RandomForestClassifier(n_estimators=11, random_state=0)
GS = GridSearchCV(rf, param_grid, cv=5)
GS.fit(train_data, train_label)
plt.plot(range(1, 20, 1), GS.cv_results_['mean_test_score'])
plt.xlabel('max_features', fontdict={'family': 'Times New Roman', 'size': 12})
plt.ylabel('准确率', fontdict={'family': 'SimSun', 'size': 12})
plt.show()
print(GS.best_params_) #输出最优参数

#验证模型是否收敛#
min_estimators = 1
max_estimators = 51
error_rate = OrderedDict(error_RF=[])
rf = RandomForestClassifier(oob_score=True, max_features=5)
for i in range(min_estimators, max_estimators + 1, 5):
    rf.set_params(n_estimators=i, random_state=0)
    rf.fit(train_data, train_label)
    oob_error = 1 - rf.oob_score_
    error_rate['error_RF'].append((i, oob_error))
for label, err in error_rate.items():
    xs, ys = zip(*err)
    x_smooth = np.linspace(np.array(xs).min(), np.array(xs).max(), 200)
    y_smooth = make_interp_spline(xs, ys)(x_smooth)
    plt.plot(x_smooth, y_smooth)

# 绘制袋外数据误差曲线
plt.xlim(min_estimators, max_estimators)
plt.ylim(0.0, 0.5)
plt.xlabel("随机森林树的棵数", fontdict={'family': 'SimSun', 'size': 12})
plt.ylabel("袋外数据误差率", fontdict={'family': 'SimSun', 'size': 12})
plt.xticks(fontproperties='Times New Roman', size=12)
plt.yticks(fontproperties='Times New Roman', size=12)
plt.show()
