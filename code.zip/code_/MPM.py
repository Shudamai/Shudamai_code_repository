#调用工具包#
from sklearn.metrics import roc_curve, auc
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from collections import OrderedDict
from scipy.interpolate import make_interp_spline
import numpy as np
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import cross_val_score

#读取预测数据#
rf_data = pd.read_csv('rf_data.csv')
data_pos = rf_data[rf_data['label1'] == 1] #正样本标签
data_neg = rf_data[rf_data['label0'] == 0] #负样本标签
data_train = pd.concat([data_pos, data_neg])
property = data_train.iloc[:, :42]
label = data_train['label1']

#制作训练集、验证集、预测集#
x_train, x_valid, y_train, y_valid = train_test_split(property, label, train_size=0.8, random_state=17) #按比例分割数据集
train_data = x_train
train_label = y_train
valid_data = property
valid_label = label
test_data = rf_data.iloc[:, :42]

#模型训练#
rf = RandomForestClassifier(n_estimators=11, max_features=5) #参数设置
rf.fit(train_data, train_label)

#模型预测#
predicted = pd.DataFrame()
output = rf.predict_proba(test_data)[:, 1]

#预测结果输出#
predicted['score'] = output
predicted['XX'] = rf_data['XX']
predicted['YY'] = rf_data['YY']
predicted['label1'] = rf_data['label1']
predicted['label0'] = rf_data['label0']
predicted.to_csv('rf_output.csv', header=True, index=False) #输出预测结果

#模型评价#
valid_y = rf.predict_proba(valid_data)[:, 1]
fpr, tpr, _ = roc_curve(valid_label, valid_y, pos_label=1, drop_intermediate=False)
roc_auc = auc(fpr, tpr)

#绘制ROC曲线#
plt.figure()
plt.title("ROC")
plt.plot(fpr, tpr, 'b', label="AUC=%0.2f" % roc_auc)
plt.legend(loc='lower right')
plt.plot([0, 1], [0, 1], 'r--')
plt.xlim([-0.05, 1.05])
plt.ylim([-0.05, 1.05])
plt.ylabel('真阳性率', fontdict={'family': 'SimSun', 'size': 12})
plt.xlabel('假阳性率', fontdict={'family': 'SimSun', 'size': 12})
plt.show()
