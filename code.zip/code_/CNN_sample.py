# 调用工具包#
import numpy as np
from osgeo import gdal
import math
import os
import random, shutil
import glob
import pandas as pd


def read_tif(path):
    gdal.AllRegister()
    filePath = path
    dataset = gdal.Open(filePath)
    Nodata = dataset.GetRasterBand(1).GetNoDataValue()

    adfGeoTransform = dataset.GetGeoTransform()
    nXSize = dataset.RasterXSize  # 列数
    nYSize = dataset.RasterYSize  # 行数
    im_data = dataset.ReadAsArray(0, 0, nXSize, nYSize)
    index = []  # 纬度
    columns = []  # 经度
    for j in range(nYSize):
        lat = adfGeoTransform[3] + j * adfGeoTransform[5]
        index.append(lat)
    for i in range(nXSize):
        lon = adfGeoTransform[0] + i * adfGeoTransform[1]
        columns.append(lon)

    data = pd.DataFrame(im_data, index=index, columns=columns).values
    XY = np.zeros([im_data.shape[0], im_data.shape[1], 2])
    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            XY[i, j, 0] = index[i]
            XY[i, j, 1] = columns[j]

    index = np.where(data == Nodata)
    data[index] = -1
    XY[index] = -1
    return data, XY


def read_data():
    Geological_files = os.listdir('./data/geological')  # 读取地质要素图层文件名
    Geological_list = []
    for Geological_file in Geological_files:
        Geological_file_path = os.path.join('./data/geological', Geological_file)
        feature_array, _ = read_tif(Geological_file_path)
        feature_array = feature_array.reshape(feature_array.shape[0], feature_array.shape[1], 1)
        Geological_list.append(feature_array)
    Geological_array = np.concatenate(Geological_list, axis=2)
    return Geological_array


all_array = read_data()  # 证据图层
np.save('data_array.npy', all_array)  # 保存预测数据

# 正负样本标签制作#
label1, HTPointXY = read_tif('./data/label/deposits.tif')  # 读取正样本栅格图层
# label1 = label1.reshape(label1.shape[0], 1)
label0, _ = read_tif('./data/label/non_deposits.tif')  # 读取负样本栅格图层
# label0 = label0.reshape(label0.shape[0], 1)
label1_copy = label1.copy()
label0_copy = label0.copy()
label1_coordinate = np.where(label1 == 1)  # 正样本坐标索引
label0_coordinate = np.where(label0 == 0)  # 负样本坐标索引

DataFrame_header = []
DataFrame_header.append('XX')
DataFrame_header.append('YY')

# all_arrayXY = pd.DataFrame(HTPointXY.T)
# all_arrayXY.columns = DataFrame_header
# all_arrayXY.to_csv(r'XY.csv', header=True, index=False)  # 输出csv格式

np.save("./data/label.npy", label1)
np.save("./data/X.npy", HTPointXY[:, :, 0])
np.save("./data/Y.npy", HTPointXY[:, :, 1])
# 设置窗口大小#
window_size = 9

# 新建文件夹，保存正负样本#
if not os.path.exists('./data/sample/1'):
    os.makedirs('./data/sample/1')  # 新建子文件夹存放正样本
    os.makedirs('./data/sample/0')  # 新建子文件夹存放负样本
else:
    print('the file exists')

# 导出正负样本
count = 0
for i in range(len(label1_coordinate[0])):
    np.save('./data/sample/1/%d' % count, all_array[
                                          label1_coordinate[0][i] - math.floor(window_size / 2):
                                          label1_coordinate[0][
                                              i] + (math.floor(
                                              window_size / 2) + 1),
                                          label1_coordinate[1][i] - math.floor(window_size / 2):
                                          label1_coordinate[1][
                                              i] + (math.floor(
                                              window_size / 2) + 1), :])
    np.save('./data/sample/0/%d' % count, all_array[
                                          label0_coordinate[0][i] - math.floor(window_size / 2):
                                          label0_coordinate[0][
                                              i] + (math.floor(
                                              window_size / 2) + 1),
                                          label0_coordinate[1][i] - math.floor(window_size / 2):
                                          label0_coordinate[1][
                                              i] + (math.floor(
                                              window_size / 2) + 1), :])
    count = count + 1
# 样本扩增#
augument_size = 3  # 扩增尺寸
for i in range(len(label1_coordinate[0])):
    label1_copy[label1_coordinate[0][i] - math.floor(augument_size / 2):label1_coordinate[0][i] + (
            math.floor(augument_size / 2) + 1),
    label1_coordinate[1][i] - math.floor(augument_size / 2):label1_coordinate[1][i] + (
            math.floor(augument_size / 2) + 1)] = np.ones((augument_size, augument_size))
    label0_copy[label0_coordinate[0][i] - math.floor(augument_size / 2):label0_coordinate[0][i] + (
            math.floor(augument_size / 2) + 1),
    label0_coordinate[1][i] - math.floor(augument_size / 2):label0_coordinate[1][i] + (
            math.floor(augument_size / 2) + 1)] = np.zeros((augument_size, augument_size))

# 新建文件夹，保存数据扩增后样本#
if not os.path.exists('./data/train_extend'):
    os.makedirs('./data/train_extend/1')
    os.makedirs('./data/train_extend/0')
if not os.path.exists('./data/valid_extend'):
    os.makedirs('./data/valid_extend/1')
    os.makedirs('./data/valid_extend/0')

# 导出扩增后的正负样本到对应的子文件夹#
index1_expend = np.argwhere(label1_copy == 1)
index0_expend = np.argwhere(label0_copy == 0)
for num_expend in range(len(index1_expend)):
    np.save('./data/train_extend/1/%d' % (num_expend), all_array[
                                                       index1_expend[num_expend][0] - math.floor(window_size / 2):
                                                       index1_expend[num_expend][0] + math.floor(window_size / 2) + 1,
                                                       index1_expend[num_expend][1] - math.floor(window_size / 2):
                                                       index1_expend[num_expend][1] + math.floor(window_size / 2) + 1,
                                                       :])
    np.save('./data/train_extend/0/%d' % (num_expend), all_array[
                                                       index0_expend[num_expend][0] - math.floor(window_size / 2):
                                                       index0_expend[num_expend][0] + math.floor(window_size / 2) + 1,
                                                       index0_expend[num_expend][1] - math.floor(window_size / 2):
                                                       index0_expend[num_expend][1] + math.floor(window_size / 2) + 1,
                                                       :])


# 划分训练集与测试集比例并保存#
def split_dataset(fileDir, tarDir):
    pathDir = os.listdir(fileDir)
    filenumber = len(pathDir)
    print(filenumber)
    rate = 0.2  # 分割比例
    picknumber = int(filenumber * rate)
    print(picknumber)
    sample = random.sample(pathDir, picknumber)
    print(sample)
    for name in sample:
        shutil.move(fileDir + name, tarDir + name)


fileDir = './data/train_extend/1/'
tarDir = './data/valid_extend/1/'
split_dataset(fileDir, tarDir)
fileDir = './data/train_extend/0/'
tarDir = './data/valid_extend/0/'
split_dataset(fileDir, tarDir)

# 训练数据集制作#
all_channel = 4
train_data = []
train_label = []
path_train = './data/train_extend'
path_train1 = glob.glob(os.path.join(path_train, "*/*.npy"))
for path in path_train1:
    a = np.load(path)
    b = a.reshape(1, window_size, window_size, all_channel)
    train_data.append(b)
    train_label.append(path.split('\\')[-2])
train_data_array = np.concatenate(train_data, axis=0)
print(train_data_array.shape[0])
train_label_array = pd.factorize(train_label)[0]
print(train_label_array.shape[0])
np.save('train_data.npy', train_data_array)  # 保存训练数据集
np.save("train_labels.npy", train_label_array)  # 保存训练数据集标签

# 验证数据集制作#
valid_data = []
valid_label = []
path_val = './data/valid_extend'
path_val1 = glob.glob(os.path.join(path_val, "*/*.npy"))
for path in path_val1:
    a = np.load(path)
    b = a.reshape(1, window_size, window_size, all_channel)
    valid_data.append(b)
    valid_label.append(path.split('\\')[-2])
valid_data_array = np.concatenate(valid_data, axis=0)
valid_label_array = pd.factorize(valid_label)[0]
np.save('valid_data.npy', valid_data_array)  # 保存验证数据集
np.save("valid_labels.npy", valid_label_array)  # 保存验证数据集标签
